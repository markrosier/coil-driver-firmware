//
//  version.h
//  
//
//  Created by Alexander Spohr on 30.04.21.
//

#ifndef version_h
#define version_h

#define MAJOR_FW_VERSION 1
#define MINOR_FW_VERSION 1

#endif /* version_h */
